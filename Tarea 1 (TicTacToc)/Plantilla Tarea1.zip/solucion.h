#pragma once

int GetEstado();
